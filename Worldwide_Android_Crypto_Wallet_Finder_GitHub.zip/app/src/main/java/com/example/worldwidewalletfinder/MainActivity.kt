package com.example.worldwidewalletfinder

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.io.BufferedReader
import java.io.InputStreamReader
import java.math.BigDecimal
import java.math.BigInteger
import java.math.RoundingMode

data class Chain(val name:String,val kind:String,val url:String,val hint:String)
val networks = listOf(
 Chain("Bitcoin (BTC)","btc","https://blockstream.info/api","1…, 3… or bc1…"),
 Chain("Ethereum (ETH)","evm","https://ethereum-rpc.publicnode.com","0x + 40 hex characters"),
 Chain("BNB Smart Chain","evm","https://bsc-rpc.publicnode.com","0x + 40 hex characters"),
 Chain("Polygon","evm","https://polygon-bor-rpc.publicnode.com","0x + 40 hex characters"),
 Chain("Base","evm","https://base-rpc.publicnode.com","0x + 40 hex characters"),
 Chain("Arbitrum One","evm","https://arbitrum-one-rpc.publicnode.com","0x + 40 hex characters"),
 Chain("Solana (SOL)","sol","https://api.mainnet-beta.solana.com","Solana public address")
)
class MainActivity:ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{
  MaterialTheme(colorScheme=darkColorScheme(primary=androidx.compose.ui.graphics.Color(0xFF70D6B2))){
   Finder()
  }
 }}
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun Finder(){
 var page by remember{mutableIntStateOf(0)}
 var ix by remember{mutableIntStateOf(0)}
 var menu by remember{mutableStateOf(false)}
 var addr by remember{mutableStateOf("")}
 var output by remember{mutableStateOf("Enter a public wallet address to inspect public on-chain information.")}
 var busy by remember{mutableStateOf(false)}
 val scope= rememberCoroutineScope()
 val c=networks[ix]
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  Text("WORLDWIDE CRYPTO WALLET FINDER",style=MaterialTheme.typography.titleLarge,color=MaterialTheme.colorScheme.primary)
  Text("Public blockchain research + safe personal recovery")
  TabRow(selectedTabIndex=page){Tab(page==0,{page=0},{Text("Worldwide research")});Tab(page==1,{page=1},{Text("My recovery")})}
  if(page==0){
   ExposedDropdownMenuBox(expanded=menu,onExpandedChange={menu=!menu}){
    OutlinedTextField(c.name,{},readOnly=true,modifier=Modifier.menuAnchor().fillMaxWidth(),label={Text("Network")},trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(menu)})
    ExposedDropdownMenu(expanded=menu,onDismissRequest={menu=false}){networks.forEachIndexed{i,n->DropdownMenuItem(text={Text(n.name)},onClick={ix=i;menu=false;output="Selected ${n.name}. Enter a public address."})}}
   }
   OutlinedTextField(addr,{addr=it.trim()},modifier=Modifier.fillMaxWidth(),label={Text("Public wallet address")},placeholder={Text(c.hint)},singleLine=true)
   Button(onClick={scope.launch{busy=true;output=withContext(Dispatchers.IO){try{lookup(c,addr)}catch(e:Exception){"Lookup failed: ${e.message}. Check the address, connection or provider status."}};busy=false}},enabled=!busy&&addr.isNotBlank(),modifier=Modifier.fillMaxWidth()){Text(if(busy)"Checking…" else "Check public blockchain data")}
   Card{Column(Modifier.padding(14.dp)){Text("Lookup result",style=MaterialTheme.typography.titleMedium);Spacer(Modifier.height(8.dp));Text(output)}}
   Text("Supported initial networks: Bitcoin, Ethereum, BNB Chain, Polygon, Base, Arbitrum and Solana.",style=MaterialTheme.typography.bodySmall)
   Text("Inactive does not mean lost. A balance does not prove ownership. Public addresses do not reveal private keys or reliably identify people.",color=MaterialTheme.colorScheme.error)
  }else{
   Text("Safe recovery checklist",style=MaterialTheme.typography.titleMedium)
   listOf("Check Settings → Apps for old wallet apps. Do not clear storage or uninstall.","Search your own email for wallet names, purchase receipts and transaction alerts.","Check your own Drive/device backups and SD cards.","Preserve old phones and backups; copy files before experimenting.","If it was an exchange, use its official account recovery process.","Restore only inside the genuine wallet app from its official source.").forEach{task->
    var checked by remember{mutableStateOf(false)}
    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Checkbox(checked,{checked=it});Text(task,Modifier.weight(1f).padding(top=10.dp))}
   }
   Card(colors=CardDefaults.cardColors(containerColor=androidx.compose.ui.graphics.Color(0xFF332515))){Text("Never enter or share your recovery phrase or private key in this app, a website, or with a recovery agent. A public address cannot be used to recover funds.",Modifier.padding(14.dp),color=androidx.compose.ui.graphics.Color(0xFFFFD27A))}
  }
  Text("Privacy: no account, no seed phrase field, no file uploads. Public address queries are sent to the selected data provider.",style=MaterialTheme.typography.bodySmall)
 }
}
fun get(url:String):String{
 val x=URL(url).openConnection() as HttpURLConnection
 x.connectTimeout=12000;x.readTimeout=12000
 return try{val code=x.responseCode;val stream=if(code in 200..299)x.inputStream else x.errorStream
 val body=BufferedReader(InputStreamReader(stream)).use{it.readText()}
 if(code !in 200..299)error("HTTP $code");body}finally{x.disconnect()}
}
fun rpc(url:String,method:String,params:String):JSONObject{
 val x=URL(url).openConnection() as HttpURLConnection
 x.requestMethod="POST";x.connectTimeout=12000;x.readTimeout=12000;x.doOutput=true;x.setRequestProperty("Content-Type","application/json")
 val body="""{"jsonrpc":"2.0","id":1,"method":"$method","params":$params}"""
 x.outputStream.use{it.write(body.toByteArray())}
 return try{val code=x.responseCode;val stream=if(code in 200..299)x.inputStream else x.errorStream
 val text=BufferedReader(InputStreamReader(stream)).use{it.readText()};if(code !in 200..299)error("HTTP $code")
 val j=JSONObject(text);if(j.has("error"))error(j.getJSONObject("error").optString("message","RPC error"));j}finally{x.disconnect()}
}
fun lookup(c:Chain,a:String):String{
 require(a.length in 20..100){"Address length looks invalid."}
 return when(c.kind){
 "btc"->{
  require(Regex("^(1|3|bc1)[a-zA-HJ-NP-Z0-9]{20,}$").matches(a)){"This does not look like a Bitcoin address."}
  val j=JSONObject(get("${c.url}/address/$a"));val cs=j.getJSONObject("chain_stats");val ms=j.getJSONObject("mempool_stats")
  val sats=cs.optLong("funded_txo_sum")+ms.optLong("funded_txo_sum")-cs.optLong("spent_txo_sum")-ms.optLong("spent_txo_sum")
  "Bitcoin\nAddress: $a\nBalance estimate: ${sats/100000000.0} BTC\nConfirmed transactions: ${cs.optInt("tx_count")}\nPending transactions: ${ms.optInt("tx_count")}\nSource: Blockstream Esplora API."
 }
 "evm"->{
  require(Regex("^0x[a-fA-F0-9]{40}$").matches(a)){"Enter a valid 0x address."}
  val b=rpc(c.url,"eth_getBalance","[\"$a\",\"latest\"]").optString("result")
  val block=rpc(c.url,"eth_blockNumber","[]").optString("result")
  val wei=BigInteger(b.removePrefix("0x").ifBlank{"0"},16)
  val native=BigDecimal(wei).divide(BigDecimal("1000000000000000000"),18,RoundingMode.DOWN).stripTrailingZeros()
  "${c.name}\nAddress: $a\nNative balance: $native\nLatest block: $block\nNote: token balances and full history are not indexed in this starter."
 }
 else->{
  require(Regex("^[1-9A-HJ-NP-Za-km-z]{32,44}$").matches(a)){"This does not look like a Solana address."}
  val j=rpc(c.url,"getBalance","[\"$a\"]")
  val lam=j.getJSONObject("result").optLong("value")
  "Solana\nAddress: $a\nNative balance: ${lam/1000000000.0} SOL\nNote: full history and token holdings require an indexed provider."
 }
 }
}
